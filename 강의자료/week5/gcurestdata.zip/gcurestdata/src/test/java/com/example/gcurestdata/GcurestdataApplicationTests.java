package com.example.gcurestdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GcurestdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
